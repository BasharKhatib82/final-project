import React from "react";

function HomePage() {
  return (
    <div className="container d-flex f-column ai-center jc-center pt-4 pb-4">
      <main className="main d-flex f-column ai-center jc-center gap-3">
        <h1 className="ta-c">ברוכים הבאים למערכת ניהול לידים</h1>

        <p className="description ta-c">
          מערכת ידידותית ודינמית לניהול פניות, משימות, שעות נוכחות עובדים,
          והרשאות משתמשים – הכל במקום אחד.
        </p>

        <ul className="features-list d-flex f-column gap-2">
          <li>ניהול פניות בצורה חכמה ומסודרת</li>
          <li>מעקב אחר שעות עבודה, חופשות והיעדרויות</li>
          <li>הקצאת משימות ודיווחי התקדמות</li>
          <li>ניהול קטגוריות והרשמות מתעניינים</li>
          <li>דוחות מתקדמים בהתאמה אישית</li>
          <li>מערכת הרשאות לפי תפקיד (מנהל כללי, מנהל שיווק, עובדי שיווק)</li>
        </ul>

        <p className="slogan ta-c">
          "יותר סדר, פחות בלגן – ניהול שמתחיל בחוויה"
        </p>
      </main>
    </div>
  );
}

export default HomePage;
