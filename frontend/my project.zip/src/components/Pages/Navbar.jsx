import React, { useEffect, useState } from "react";
import { NavLink, useNavigate, Link } from "react-router-dom";
import logo from "../../assets/img/logo.png";

function Navbar() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");
    setIsLoggedIn(!!token);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    setIsLoggedIn(false);
    navigate("/");
  };

  return (
    <div className="header">
      <div className="header__wrap">
        {/* קישורי ניווט */}
        <div className="navbar-links">
          <NavLink
            to="/"
            className={({ isActive }) =>
              isActive ? "btn-glo active-btn" : "btn-glo inactive-btn"
            }
          >
            דף ראשי
          </NavLink>
          <NavLink
            to="/about"
            className={({ isActive }) =>
              isActive ? "btn-glo active-btn" : "btn-glo inactive-btn"
            }
          >
            אודות
          </NavLink>
          <NavLink
            to="/contact"
            className={({ isActive }) =>
              isActive ? "btn-glo active-btn" : "btn-glo inactive-btn"
            }
          >
            צור קשר
          </NavLink>
        </div>

        {/* לוגו */}
        <Link to="/">
          <img className="logo-img" src={logo} alt="לוגו" />
        </Link>

        {/* התחברות/התנתקות */}
        <div className="navbar-links">
          {!isLoggedIn ? (
            <NavLink
              to="/userlogin"
              className={({ isActive }) =>
                isActive ? "btn-glo active-btn" : "btn-glo inactive-btn"
              }
            >
              התחברות
            </NavLink>
          ) : (
            <NavLink
              to="/userlogout"
              className={({ isActive }) =>
                isActive ? "btn-glo active-btn" : "btn-glo inactive-btn"
              }
            >
              התנתקות
            </NavLink>
          )}
        </div>
      </div>
    </div>
  );
}

export default Navbar;
