import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function Login() {
  const [values, setValues] = useState({
    user_id: "",
    password: "",
  });

  const [error, setError] = useState(null);
  const navigate = useNavigate();
  axios.defaults.withCredentials = true;

  const handleSubmit = (event) => {
    event.preventDefault();
    axios
      .post("http://localhost:3000/auth/userlogin", values)
      .then((result) => {
        if (result.data.loginStatus) {
          navigate("/dashboard");
        } else {
          setError(result.data.Error);
        }
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="container">
      <div className="main">
        <div className="login ">
          <div className="massage-err fs16p">{error && error}</div>
          <h1 className="t-al-c">התחברות למערכת</h1>
          <form onSubmit={handleSubmit}>
            <div>
              <label htmlFor="user_id fs16p">
                <strong>תעודת זהות : </strong>
              </label>
              <input
                type="number"
                name="user_id"
                autoComplete="off"
                placeholder="הקלד תעודת זהות"
                onChange={(e) =>
                  setValues({ ...values, user_id: e.target.value })
                }
                className="form-login"
              />
            </div>
            <div>
              <label htmlFor="password">
                <strong>סיסמה : </strong>
              </label>
              <input
                type="password"
                name="password"
                placeholder="הכנס סיסמה"
                onChange={(e) =>
                  setValues({ ...values, password: e.target.value })
                }
                className="form-login"
              />
            </div>
            <button className="btn-login">התחברות</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
