import React from "react";

const EditHours = () => {
  return <div>EditHours</div>;
};

export default EditHours;
