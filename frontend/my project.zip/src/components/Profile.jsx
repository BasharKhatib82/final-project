import React from "react";

const Profile = () => {
  return (
    <div className="container">
      <div className="main">
        <div>Profile</div>
      </div>
    </div>
  );
};

export default Profile;
