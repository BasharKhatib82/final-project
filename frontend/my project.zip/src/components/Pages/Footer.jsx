import React from "react";

function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer>
      <p className="ta-c">
        Developed by Tareq Shaltaf & Bashar Khatib | &copy; {currentYear}
      </p>
    </footer>
  );
}

export default Footer;
