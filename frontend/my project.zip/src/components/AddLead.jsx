import React from "react";

const AddLead = () => {
  return <div>AddLeads</div>;
};

export default AddLead;
